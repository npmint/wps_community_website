Pakiet s�ownik�w zosta� stworzony przez projekt OpenOffice.org po polsku,
a obecnie modyfikowany jest przez zesp� Dobrego s�ownika.
Zawiera s�owniki w r�nych wersjach w tym najnowsz� z dnia 2016.01.25;
Strona g��wna projektu: http://pl.openoffice.org

S�ownik synonim�w - wersja do programu OpenOffice.org
-----------------------------------------------------
Copyright (C) 2014-2016 Dobry s�ownik <redakcja@dobryslownik.pl>
Copyright (C) 2004-2014 Marcin Mi�kowski <milek_pl@users.sourceforge.net>
Licencja: LGPL 2.1.

Wersja wygenerowana automatycznie dnia 2016.01.25;
Strona g��wna: http://dobryslownik.pl

Korektor pisowni
----------------
Niniejszy s�ownik do sprawdzania pisowni jest udost�pniany na licencjach
GPL, LGPL, MPL (Mozilla Public License), Apache 2.0 (zobacz http://www.apache.org/licenses/LICENSE-2.0)
i Creative Commons ShareAlike (zobacz http://creativecommons.org/licenses/sa/1.0).

Data utworzenia tej wersji s�ownika: 2015-04-28
Najnowsz� wersj� mo�na pobra� ze strony:
http://www.sjp.pl/

Opiekun s�ownika: Marek Futrega (futrega@gmail.com)