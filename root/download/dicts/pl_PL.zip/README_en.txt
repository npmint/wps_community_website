This dictionary pack was created by the Polish Native Lang Project.
Since September 2014 is maintaned by Dobry s�ownik (http://dobryslownik.pl).
The pack contains versions of all OpenOffice.org dictionares. The latest is from 2016.01.25.
Project homepage: http://pl.openoffice.org

Thesaurus
----------
Copyright (C) 2014-2016 Dobry s�ownik <redakcja@dobryslownik.pl>
Copyright (C) 2004-2014 Marcin Mi�kowski <milek_pl@users.sourceforge.net>
This product is made available subject to the terms of GNU Lesser 
General Public License Version 2.1.

Generated on 2016.01.25. 
Homepage: http://dobryslownik.pl

Spellchecker
------------

This dictionary for spell-checking Polish texts is licensed under
GPL, LGPL, MPL (Mozilla Public License), Apache 2.0 (see http://www.apache.org/licenses/LICENSE-2.0)
and Creative Commons ShareAlike licenses (see http://creativecommons.org/licenses/sa/1.0).

This version of the dictionary was generated on 2015-04-28
The most up-to-date version can be found at:
http://www.sjp.pl/slownik/en/

Dictionary maintainer: Marek Futrega (futrega@gmail.com)