Croatian WPS dictionary - dictionary for KingSoft Office format
---------------------------------------------------------------

Language: Croatian - Hrvatski (hr HR).
License:  LGPL/SISSL license, 2016
Author:   Nenad Dev�i�
Mail:     nenad0456@gmail.com
