Adaptación del dicionario Catalán de Open Office (por Sergio Sacristán - s2o)
